from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

# load the dataset
dataset = load_dataset("Yelp/yelp_review_full")

print(dataset)
print(dataset["train"].unique("label"))

# load the pre-trained model and its tokenizer
model_name = "distilbert/distilbert-base-cased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
# note that we have to correctly specify the number of labels
model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=len(dataset["train"].unique("label")))

# take a subset of data to create training, evaluation, and test sets
train_ds = dataset["train"].shuffle(seed=42).select(range(50_000))
eval_ds = dataset["test"].select(range(5_000))
test_ds = dataset["test"].skip(5_000).select(range(5_000))


# applying tokenization in batches
def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True)

tokenized_train_ds = train_ds.map(tokenize_function, batched=True)
tokenized_eval_ds = eval_ds.map(tokenize_function, batched=True)
tokenized_test_ds = test_ds.map(tokenize_function, batched=True)


# we need to define a function to compute the metrics
def compute_metrics(p):
    return {"accuracy": (p.predictions.argmax(axis=1) == p.label_ids).mean()}


# define the training arguments
training_args = TrainingArguments(
    output_dir="results",
    eval_strategy="epoch",
    learning_rate=1e-5,
    per_device_train_batch_size=64,
    per_device_eval_batch_size=64,
    num_train_epochs=3,
    weight_decay=0.01,
)

# define the trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_train_ds,
    eval_dataset=tokenized_eval_ds,
    processing_class=tokenizer,
    compute_metrics=compute_metrics,
)

# train the model
trainer.train()

# save the model
trainer.save_model("distilbert-base-cased-yelp-review")

# evaluate the model
print(trainer.evaluate(tokenized_test_ds))