#!/bin/bash -l
#SBATCH --job-name="practice"
#SBATCH --time 01:00:00
#SBATCH --partition=gpu
#SBATCH --gres=gpu:tesla:1
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=12GB

# disable built-in parallelization in tokenizers
export TOKENIZERS_PARALLELISM=false

# activate the virtual environment as it's not going to run in your user shell
source practice_env/bin/activate
# run the training 
srun python train.py

